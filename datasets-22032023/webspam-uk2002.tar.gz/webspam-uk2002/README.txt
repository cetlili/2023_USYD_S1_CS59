
(C) 2006  D.I.S. - University 'La Sapienza' of Rome.

Details about the classification process can be found in [1,2]. The format of
this data set is: one hostname per line, followed by the word «normal», «spam»
or «suspicious». The link structure of this graph is available from the
download page of UK-2002 at University of Milano [3].  Unfortunately we do not
have the contents of the pages.

LICENSE

The data set is freely available as per a CC-by-nc-sa license [4], which
basically states that you are free to use the data and that we make no
warranties about it. Note that you can use the data for any purpose, even in a
commercial environment. The "nc-sa" rule (non-commercial, share-alike) apply
only if you want to redistribute the data publicly. We advice you not to use
these labels directly for search engine ranking, as this data set was built for
research purposes.

[1]
Luca Becchetti, Carlos Castillo, Debora Donato, Stefano Leonardi, Ricardo
Baeza-Yates: "Using Rank Propagation and Probabilistic Counting for Link-Based
Spam Detection". Technical report DELIS-TR-0341. 2006.

[2]
Luca Becchetti, Carlos Castillo, Debora Donato, Stefano Leonardi, Ricardo
Baeza-Yates: "Link-Based Characterization and Detection of Web Spam". 
Workshop on Adversarial Information Retrieval on the Web (AIRWeb).
Seattle, USA, August 2006. 

[3]
http://nexus.law.dsi.unimi.it/webdata/uk-2002/

[4]
http://creativecommons.org/licenses/by-nc-sa/2.5/deed.en
